
const express = require('express');
const Parser = require('rss-parser');
const cors = require('cors');

const app = express();
const parser = new Parser();
app.use(cors());

let items = [];

const rssFeeds = [
  'https://www.ynet.co.il/Integration/StoryRss2.xml',
  'https://rss.walla.co.il/feed/1?name=walla',
  'https://www.maariv.co.il/rss/rss/1',
  'https://www.israelhayom.co.il/rss.xml',
  'https://www.kan.org.il/rss/news.xml',
  'https://www.14tv.co.il/feed/'
];

async function fetchFeeds() {
  try {
    const all = await Promise.all(
      rssFeeds.map(url => parser.parseURL(url))
    );
    let combined = all.flatMap(feed =>
      feed.items.map(i => ({
        title: i.title,
        link: i.link,
        pubDate: new Date(i.pubDate || i.isoDate),
        source: feed.title || 'מקור לא ידוע'
      }))
    );
    combined.sort((a, b) => b.pubDate - a.pubDate);
    items = [...new Map(combined.map(i => [i.link, i])).values()].slice(0, 50);
  } catch (e) {
    console.error('שגיאה בשליפת עדכונים:', e);
  }
}

setInterval(fetchFeeds, 60000);
fetchFeeds();

app.use(express.static('public'));

app.get('/news', (req, res) => {
  res.json(items);
});

app.listen(3000, () => {
  console.log('שרת חמ"ל רץ על http://localhost:3000');
});
